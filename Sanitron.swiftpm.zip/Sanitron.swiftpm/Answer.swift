import Foundation

struct Answer: Identifiable {
    
    var id = UUID()
    var txt : String
    var isCorrect : Bool
    
}
