import Foundation

enum AnalysisError: Error {
    case emptyInput
    case mlError
    case invalidInput
}
